import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  createUserWithEmailAndPassword, onAuthStateChanged, signInWithEmailAndPassword,
  signOut, updateProfile
} from "firebase/auth";
import {
  addDoc, collection, doc, getDoc, onSnapshot, orderBy, query, serverTimestamp,
  setDoc, where, limit
} from "firebase/firestore";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import { auth, db, storage } from "./firebase";
import { MessageCircle, Users, ImagePlus, Mic, Send, LogOut, Shield, Globe, X } from "lucide-react";

const t = {
  en: {
    name:"Namma Community", subtitle:"A place to connect", login:"Sign in", signup:"Create account",
    email:"Email address", password:"Password", display:"Display name", signout:"Sign out",
    rooms:"Groups", people:"Community", private:"Private chat", group:"Group chat",
    write:"Write a message…", send:"Send", photo:"Photo", voice:"Voice", admin:"Admin",
    noMessages:"No messages yet. Start the conversation!", loginTitle:"Welcome back",
    registerTitle:"Join the community", create:"Create account", signIn:"Sign in",
    members:"Members", makeGroup:"Create group", groupName:"Group name", cancel:"Cancel",
    sendError:"Could not send. Check your connection and Firebase setup.",
    recording:"Recording… tap to stop", startVoice:"Record voice message",
    empty:"Choose a group or person to begin.", adminTitle:"Admin panel",
    adminInfo:"Admin tools are available only to accounts granted the admin role.",
    roleHint:"Set role = admin for your account in Firestore Console → users → your UID.",
    report:"Report", reported:"Report sent to moderators", language:"Language"
  },
  ml: {
    name:"നമ്മുടെ കമ്മ്യൂണിറ്റി", subtitle:"ഒരുമിച്ച് ബന്ധപ്പെടാം", login:"ലോഗിൻ", signup:"അക്കൗണ്ട് തുടങ്ങുക",
    email:"ഇമെയിൽ വിലാസം", password:"പാസ്‌വേഡ്", display:"പേര്", signout:"ലോഗ് ഔട്ട്",
    rooms:"ഗ്രൂപ്പുകൾ", people:"അംഗങ്ങൾ", private:"സ്വകാര്യ ചാറ്റ്", group:"ഗ്രൂപ്പ് ചാറ്റ്",
    write:"സന്ദേശം എഴുതുക…", send:"അയയ്ക്കുക", photo:"ഫോട്ടോ", voice:"വോയ്സ്",
    admin:"അഡ്മിൻ", noMessages:"സന്ദേശങ്ങളില്ല. സംഭാഷണം ആരംഭിക്കൂ!", loginTitle:"വീണ്ടും സ്വാഗതം",
    registerTitle:"കമ്മ്യൂണിറ്റിയിൽ ചേരുക", create:"അക്കൗണ്ട് തുടങ്ങുക", signIn:"ലോഗിൻ",
    members:"അംഗങ്ങൾ", makeGroup:"ഗ്രൂപ്പ് സൃഷ്ടിക്കുക", groupName:"ഗ്രൂപ്പിന്റെ പേര്",
    cancel:"റദ്ദാക്കുക", sendError:"അയയ്ക്കാനായില്ല. കണക്ഷനും Firebase ക്രമീകരണവും പരിശോധിക്കുക.",
    recording:"റെക്കോർഡ് ചെയ്യുന്നു… നിർത്താൻ അമർത്തുക", startVoice:"വോയ്സ് സന്ദേശം റെക്കോർഡ് ചെയ്യുക",
    empty:"തുടങ്ങാൻ ഒരു ഗ്രൂപ്പോ വ്യക്തിയോ തിരഞ്ഞെടുക്കുക.", adminTitle:"അഡ്മിൻ പാനൽ",
    adminInfo:"അഡ്മിൻ അനുമതിയുള്ള അക്കൗണ്ടുകൾക്ക് മാത്രമേ ഈ സൗകര്യം ലഭിക്കൂ.",
    roleHint:"Firestore Console → users → നിങ്ങളുടെ UID-ൽ role = admin ആയി ക്രമീകരിക്കുക.",
    report:"റിപ്പോർട്ട്", reported:"മോഡറേറ്റർമാർക്ക് റിപ്പോർട്ട് അയച്ചു", language:"ഭാഷ"
  }
};

export default function App() {
  const [lang,setLang] = useState("ml");
  const L = t[lang];
  const [user,setUser] = useState(null);
  const [profile,setProfile] = useState(null);
  const [mode,setMode] = useState("login");
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [displayName,setDisplayName] = useState("");
  const [error,setError] = useState("");
  const [tab,setTab] = useState("groups");
  const [active,setActive] = useState(null);
  const [messages,setMessages] = useState([]);
  const [text,setText] = useState("");
  const [groups,setGroups] = useState([]);
  const [people,setPeople] = useState([]);
  const [showGroup,setShowGroup] = useState(false);
  const [groupName,setGroupName] = useState("");
  const [recording,setRecording] = useState(false);
  const [adminStats,setAdminStats] = useState({users:0,groups:0});
  const fileRef = useRef(null);
  const recorderRef = useRef(null);
  const chunksRef = useRef([]);
  const bottomRef = useRef(null);

  useEffect(() => onAuthStateChanged(auth, async u => {
    setUser(u);
    if (u) {
      const snap = await getDoc(doc(db,"users",u.uid));
      setProfile(snap.exists() ? snap.data() : { displayName:u.displayName || "Member", role:"member" });
    } else { setProfile(null); setActive(null); }
  }), []);

  useEffect(() => {
    if (!user) return;
    const unsubUsers = onSnapshot(collection(db,"users"), s => {
      setPeople(s.docs.map(d=>({id:d.id,...d.data()})).filter(p=>p.id!==user.uid));
    });
    const unsubGroups = onSnapshot(collection(db,"groups"), s => setGroups(s.docs.map(d=>({id:d.id,...d.data()}))));
    return () => { unsubUsers(); unsubGroups(); };
  },[user]);

  useEffect(() => {
    if (!user || !active) { setMessages([]); return; }
    const q = query(collection(db,"messages"), where("roomId","==",active.id), orderBy("createdAt","asc"), limit(150));
    return onSnapshot(q, s => setMessages(s.docs.map(d=>({id:d.id,...d.data()}))), e=>setError(e.message));
  },[user,active]);

  useEffect(()=>bottomRef.current?.scrollIntoView({behavior:"smooth"}),[messages]);

  useEffect(() => {
    if (!user || profile?.role!=="admin") return;
    const a=onSnapshot(collection(db,"users"),s=>setAdminStats(v=>({...v,users:s.size})));
    const b=onSnapshot(collection(db,"groups"),s=>setAdminStats(v=>({...v,groups:s.size})));
    return ()=>{a();b();};
  },[user,profile]);

  const isAdmin = profile?.role === "admin";
  const activeTitle = active?.title || "";
  const roomId = active?.id;

  async function authenticate(e) {
    e.preventDefault(); setError("");
    try {
      if (mode==="signup") {
        const cred=await createUserWithEmailAndPassword(auth,email,password);
        await updateProfile(cred.user,{displayName});
        await setDoc(doc(db,"users",cred.user.uid),{
          displayName, email, role:"member", createdAt:serverTimestamp()
        });
        setProfile({displayName,role:"member"});
      } else await signInWithEmailAndPassword(auth,email,password);
    } catch(err) { setError(err.message); }
  }

  async function sendMessage(extra={}) {
    if (!roomId || (!text.trim() && !extra.mediaUrl)) return;
    try {
      await addDoc(collection(db,"messages"),{
        roomId, roomType:active.type, text:text.trim(), senderId:user.uid,
        senderName:profile?.displayName || user.displayName || "Member",
        createdAt:serverTimestamp(), ...extra
      });
      setText("");
    } catch(e) { setError(L.sendError); }
  }

  async function uploadFile(file,kind) {
    if (!file || !roomId) return;
    const max = kind==="image" ? 8*1024*1024 : 5*1024*1024;
    if (file.size>max) { setError(kind==="image"?"Image must be under 8 MB":"Voice message must be under 5 MB"); return; }
    const path=`chatUploads/${roomId}/${user.uid}/${Date.now()}-${file.name || "voice.webm"}`;
    const r=ref(storage,path);
    await uploadBytes(r,file);
    const url=await getDownloadURL(r);
    await sendMessage({mediaUrl:url,mediaType:kind});
  }

  async function choosePhoto(e) {
    const f=e.target.files?.[0]; if(f) await uploadFile(f,"image");
    e.target.value="";
  }

  async function toggleVoice() {
    if (recording) { recorderRef.current?.stop(); setRecording(false); return; }
    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) {
      setError("Voice recording is not supported by this browser."); return;
    }
    try {
      const stream=await navigator.mediaDevices.getUserMedia({audio:true});
      const rec=new MediaRecorder(stream); recorderRef.current=rec; chunksRef.current=[];
      rec.ondataavailable=e=>{if(e.data.size) chunksRef.current.push(e.data);};
      rec.onstop=async()=>{
        const blob=new Blob(chunksRef.current,{type:rec.mimeType || "audio/webm"});
        stream.getTracks().forEach(track=>track.stop());
        await uploadFile(new File([blob],"voice-message.webm",{type:blob.type}),"audio");
      };
      rec.start(); setRecording(true);
    } catch(e) { setError("Microphone permission is required."); }
  }

  async function createGroup(e) {
    e.preventDefault(); if(!groupName.trim()) return;
    const refDoc=await addDoc(collection(db,"groups"),{
      name:groupName.trim(), createdBy:user.uid, members:[user.uid], createdAt:serverTimestamp()
    });
    setActive({id:refDoc.id,title:groupName.trim(),type:"group"});
    setGroupName(""); setShowGroup(false);
  }

  async function reportMessage(message) {
    await addDoc(collection(db,"reports"),{
      messageId:message.id, roomId:message.roomId, reportedBy:user.uid,
      senderId:message.senderId, createdAt:serverTimestamp(), status:"open"
    });
    alert(L.reported);
  }

  function openGroup(g) { setActive({id:g.id,title:g.name,type:"group"}); setTab("groups"); }
  function openPerson(p) {
    const ids=[user.uid,p.id].sort();
    setActive({id:`dm_${ids[0]}_${ids[1]}`,title:p.displayName || "Member",type:"private"});
    setTab("people");
  }

  if (!user) return <div className="auth-shell">
    <div className="auth-card">
      <div className="brand-mark"><MessageCircle size={28}/></div>
      <div className="eyebrow">NAMMA COMMUNITY</div>
      <h1>{mode==="login"?L.loginTitle:L.registerTitle}</h1>
      <p>{L.subtitle} · {lang==="ml"?"മലയാളം & English":"Malayalam & English"}</p>
      <form onSubmit={authenticate} className="auth-form">
        {mode==="signup" && <label>{L.display}<input required value={displayName} onChange={e=>setDisplayName(e.target.value)} /></label>}
        <label>{L.email}<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} /></label>
        <label>{L.password}<input required minLength="6" type="password" value={password} onChange={e=>setPassword(e.target.value)} /></label>
        {error && <div className="error">{error}</div>}
        <button className="primary wide">{mode==="login"?L.signIn:L.create}</button>
      </form>
      <button className="link-btn" onClick={()=>{setMode(mode==="login"?"signup":"login");setError("");}}>
        {mode==="login"?L.signup:L.login}
      </button>
      <button className="lang-btn" onClick={()=>setLang(lang==="ml"?"en":"ml")}><Globe size={15}/>{lang==="ml"?"English":"മലയാളം"}</button>
    </div>
  </div>;

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="brand-mark small"><MessageCircle size={20}/></div><div><b>{L.name}</b><small>{L.subtitle}</small></div></div>
      <div className="top-actions">
        <button className="icon-btn" title={L.language} onClick={()=>setLang(lang==="ml"?"en":"ml")}><Globe size={18}/><span>{lang==="ml"?"EN":"മലയാളം"}</span></button>
        <span className="user-chip">{profile?.displayName || user.email}</span>
        <button className="icon-btn" title={L.signout} onClick={()=>signOut(auth)}><LogOut size={18}/></button>
      </div>
    </header>

    <div className="layout">
      <aside className="sidebar">
        <div className="side-tabs">
          <button className={tab==="groups"?"selected":""} onClick={()=>setTab("groups")}><Users size={17}/>{L.rooms}</button>
          <button className={tab==="people"?"selected":""} onClick={()=>setTab("people")}><MessageCircle size={17}/>{L.people}</button>
        </div>
        {tab==="groups" ? <>
          <div className="side-heading">{L.group}<button className="plus" onClick={()=>setShowGroup(true)}>+</button></div>
          {groups.map(g=><button key={g.id} className={`list-item ${active?.id===g.id?"active":""}`} onClick={()=>openGroup(g)}><span className="avatar">#</span><span>{g.name}</span></button>)}
        </> : <>
          <div className="side-heading">{L.private}</div>
          {people.map(p=><button key={p.id} className={`list-item ${active?.title===p.displayName?"active":""}`} onClick={()=>openPerson(p)}><span className="avatar">{(p.displayName||"U")[0].toUpperCase()}</span><span>{p.displayName||"Member"}</span></button>)}
        </>}
        {isAdmin && <button className="admin-link" onClick={()=>setTab("admin")}><Shield size={17}/>{L.adminTitle}</button>}
        <div className="sidebar-bottom"><span className="online-dot"/> {profile?.displayName || "Member"} <small>· {isAdmin?"Admin":"Member"}</small></div>
      </aside>

      <main className="chat-panel">
        {tab==="admin" && isAdmin ? <div className="admin-view">
          <div className="eyebrow">CONTROL CENTER</div><h2>{L.adminTitle}</h2><p>{L.adminInfo}</p>
          <div className="stats"><div><b>{adminStats.users}</b><span>{L.members}</span></div><div><b>{adminStats.groups}</b><span>{L.rooms}</span></div></div>
          <div className="notice"><Shield size={18}/><span>{L.roleHint}</span></div>
          <p className="muted">Review reports in the Firestore <code>reports</code> collection. Remove abusive content through the Firebase Console after review.</p>
        </div> : active ? <>
          <div className="chat-head"><div className="avatar big">{active.type==="group"?"#":activeTitle[0]?.toUpperCase()}</div><div><b>{activeTitle}</b><small>{active.type==="group"?L.group:L.private}</small></div></div>
          <div className="messages">
            {messages.length===0 && <div className="empty-state">{L.noMessages}</div>}
            {messages.map(m=><div key={m.id} className={`message-row ${m.senderId===user.uid?"mine":""}`}>
              <div className="bubble">
                {m.senderId!==user.uid && <b className="sender">{m.senderName}</b>}
                {m.text && <p>{m.text}</p>}
                {m.mediaType==="image" && <a href={m.mediaUrl} target="_blank" rel="noreferrer"><img className="shared-image" src={m.mediaUrl} alt="Shared upload"/></a>}
                {m.mediaType==="audio" && <audio controls src={m.mediaUrl}/>}
                <div className="message-meta">{m.createdAt?.toDate ? m.createdAt.toDate().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}) : "…"}
                  {m.senderId!==user.uid && <button onClick={()=>reportMessage(m)}>{L.report}</button>}
                </div>
              </div>
            </div>)}
            <div ref={bottomRef}/>
          </div>
          <div className="composer">
            <input ref={fileRef} type="file" accept="image/*" hidden onChange={choosePhoto}/>
            <button className="tool-btn" title={L.photo} onClick={()=>fileRef.current?.click()}><ImagePlus size={20}/></button>
            <button className={`tool-btn ${recording?"recording":""}`} title={recording?L.recording:L.startVoice} onClick={toggleVoice}><Mic size={20}/></button>
            <input className="message-input" value={text} onChange={e=>setText(e.target.value)} placeholder={L.write} onKeyDown={e=>e.key==="Enter"&&!e.shiftKey&&(e.preventDefault(),sendMessage())}/>
            <button className="send-btn" onClick={()=>sendMessage()} disabled={!text.trim()}><Send size={18}/><span>{L.send}</span></button>
          </div>
          {recording && <div className="record-hint">{L.recording}</div>}
        </> : <div className="welcome"><div className="welcome-icon"><MessageCircle size={34}/></div><h2>{L.name}</h2><p>{L.empty}</p></div>}
      </main>
    </div>

    {showGroup && <div className="modal-backdrop"><form className="modal" onSubmit={createGroup}><button type="button" className="modal-close" onClick={()=>setShowGroup(false)}><X size={18}/></button><h3>{L.makeGroup}</h3><label>{L.groupName}<input autoFocus value={groupName} onChange={e=>setGroupName(e.target.value)} required maxLength="50"/></label><div className="modal-actions"><button type="button" className="secondary" onClick={()=>setShowGroup(false)}>{L.cancel}</button><button className="primary">{L.create}</button></div></form></div>}
    {error && <button className="toast" onClick={()=>setError("")}>{error}　×</button>}
  </div>;
}